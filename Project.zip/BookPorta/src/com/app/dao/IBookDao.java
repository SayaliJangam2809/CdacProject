package com.app.dao;

import java.util.List;

//import org.springframework.stereotype.Repository;

import com.app.pojos.Book;
import com.app.pojos.Cart;
import com.app.pojos.Order;


public interface IBookDao {

	List<Book> showAllBookList();

	

	String addBook(Book b);



	String removeBook(int bid);



	
	  String buyBook(int bid, int uid);
	  
	  
	  
	  List<Order> showOrderList(int bid, int uid);



	List<Cart> order();
	 
		
	
}
