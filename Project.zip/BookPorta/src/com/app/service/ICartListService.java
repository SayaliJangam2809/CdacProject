package com.app.service;

import java.util.List;

import com.app.pojos.Cart;

public interface ICartListService {
List<Cart> cartList(int uid);


}
