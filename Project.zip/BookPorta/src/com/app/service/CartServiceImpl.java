package com.app.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.ICartDao;

import com.app.pojos.Cart;

@Service
@Transactional
public class CartServiceImpl implements ICartService {

	@Autowired
	private ICartDao dao;
	@Override
	public Cart addToCart(int bid,int uid)
	{
		System.out.println("addToCart service");
		return dao.addToCart(bid,uid);
	}
@Override
	public String deleteFromCart(int bid, int uid) {
		
		return dao.deleteFromCart(bid,uid);
	}
}
