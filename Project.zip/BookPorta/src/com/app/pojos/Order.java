package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="order")
public class Order {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private int oid;
	
	@Column(length = 30)
	private String name;
	
	private int b_id;
	private int uid;
	
	private double price;

	public Order() {
		System.out.println("In def constr of Order..");
	}

	
	public Order(int oid, String name, int b_id, int uid, double price) {
		super();
		this.oid = oid;
		this.name = name;
		this.b_id = b_id;
		this.uid = uid;
		this.price = price;
	}


	public Order( int oid,int b_id,String name,  double price,int uid) {
		super();
		this.oid = oid;
		this.b_id = b_id;
		this.name = name;
		this.price = price;
		this.uid = uid;
	}

	
	
	public int getOid() {
		return oid;
	}


	public void setOid(int oid) {
		this.oid = oid;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getB_id() {
		return b_id;
	}

	public void setB_id(int b_id) {
		this.b_id = b_id;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Order [oid=" + oid + ", name=" + name + ", b_id=" + b_id + ", uid=" + uid + ", price=" + price + "]";
	}

	

	
	
	
	
}
