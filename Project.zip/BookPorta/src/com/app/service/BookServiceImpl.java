package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IBookDao;
import com.app.pojos.Book;
import com.app.pojos.Cart;
import com.app.pojos.Order;

@Service
@Transactional
public class BookServiceImpl implements IBookService {

	@Autowired
	private IBookDao dao;
	
	@Override
	public List<Book> showAllBookList() {
		System.out.println("In Book Service..");
		return dao.showAllBookList();
	}
 @Override
 public String addBook(Book b)
 {
	 System.out.println("In Service Add to book");
	 return dao.addBook(b);
 }
 @Override
public String removeBook(int bid) {
	
	return dao.removeBook(bid);
}

  @Override public String buyBook(int bid, int uid) {
  System.out.println("In buy book service"); return dao.buyBook(bid, uid); }
  
  @Override public List<Order> showOrderList(int bid, int uid) {
  System.out.println("in show order list service"); return
  dao.showOrderList(bid, uid); 
  
  }
  @Override
public List<Cart> order() {
	
	return dao.order();
}
 
}
