package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.service.ICartService;
import com.app.service.ICustomerService;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	private ICustomerService service;
	 @Autowired
	 private ICartService cartService;
	
	public CustomerController() {
		System.out.println("In constructor of "+getClass().getName());
	}
	
		
@GetMapping("/details")
public String showCustomerDetails()
{
	System.out.println("In show Customer Page");
	return "redirect:/book/list";
	//return "/customer/details";
}

@GetMapping("/list")
public String showCustomerList(Model map)
{
	System.out.println("In showCustomerList"+map);
	map.addAttribute("customer_list",service.showAllCustomer());
	return "/customer/list";
}
@GetMapping("/list1")
public String showCustomerListAdmin(Model map)
{
	System.out.println("In showCustomerList"+map);
	map.addAttribute("customer_list",service.showAllCustomer1());
	return "/admin/customerList";
}
 @GetMapping("/cart")
 public String addToCart (@RequestParam int bid, @RequestParam int uid,HttpSession hs,Model map)
 {
	 
	System.out.println("In addToCart");
	hs.setAttribute("cart_list",cartService.addToCart(bid,uid));
	map.addAttribute("bookAdded", "Book added to cart...");
	return "/book/list";
}
 @GetMapping("/deleteBook")
	public String deleteBookFromCart(@RequestParam int bid, @RequestParam int uid,HttpSession hs,Model map)
	{
		
	   System.out.println("In delete from Cart");
		hs.setAttribute("cart_list",cartService.deleteFromCart(bid,uid));
		map.addAttribute("bookDeleted", "Book deleted from cart...");
		return "/customer/cart";
	}
@GetMapping("/removeCustomer")
public String removeCustomer(@RequestParam int uid,HttpSession hs,Model map)
{
	map.addAttribute("removeCustomer", service.removeCustomer(uid));
	return "redirect:/customer/list1";
}



}
