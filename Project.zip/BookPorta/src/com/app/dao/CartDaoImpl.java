package com.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.app.pojos.Book;
import com.app.pojos.Cart;

@Repository
public class CartDaoImpl implements ICartDao {
@Autowired
private SessionFactory sf;
	@Override
	public Cart addToCart(int bid,int uid) {
		System.out.println("addToCart dao");
		 Session session=sf.getCurrentSession();
		  Book b=session.get(Book.class, bid);
		  
		  int bookId=b.getB_id(); 
		  String name=b.getName();
		  Double price=b.getPrice();
		  
		  Cart cart=new Cart(bookId,name,price,uid);
		  System.out.println("book ID"+bookId+"name"+name+"price"+price+"uid"+uid);
		  sf.getCurrentSession().save(cart);
		  
		  return cart;
		 }
	@Override
		public String deleteFromCart(int bid, int uid) {
		System.out.println("In delete cart");
		String query="select u from Cart u where u.b_id=:bid and u.uid=:uid";

	List<Cart> c=sf.getCurrentSession().createQuery(query,Cart.class).setParameter(
				  "bid", bid).setParameter("uid", uid).getResultList();
	
	
	  for(Cart dict : c) { sf.getCurrentSession().delete(dict);
	  System.out.println("perform deletion"); }
	 
		//sf.getCurrentSession().delete(c);
		
			/*
			 * String query="select u from Cart u where u.b_id=:bid and u.uid=:uid";
			 * 
			 * List<Cart>
			 * deleteBook=sf.getCurrentSession().createQuery(query,Cart.class).setParameter(
			 * "bid", bid).setParameter("uid", uid).getResultList();
			 * sf.getCurrentSession().delete(sf.getCurrentSession().createQuery(query,Cart.class).setParameter(
			 * "bid", bid).setParameter("uid", uid).getResultList(););
			 */
			 //return EntityManager.createQuery(query,Cart.class).setParameter("bid", bid).setParameter("uid", uid).getResultList();
				/*
				 * String query="select u from Cart u where u.b_id=:bid and u.uid=:uid";
				 * 
				 * sf.getCurrentSession().delete(sf.getCurrentSession().createQuery(query,Cart.
				 * class).setParameter( "bid", bid).setParameter("uid", uid).getResultList());
				 * System.out.println("permorm deletion");
				 */
		/*
		 * String msg="vendor deletion failsed"; Session session=sf.getCurrentSession();
		 * Cart u=session.get(Cart.class, bid);
		 */
		
		/* session.delete(u); */
		return "deleted from cart";
			
		}
	

}
