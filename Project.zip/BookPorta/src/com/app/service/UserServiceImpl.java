package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IUserDao;
import com.app.pojos.User;

@Service
@Transactional
public class UserServiceImpl implements IUserService {
	@Autowired
	private IUserDao dao;
	@Override
	public User authenticateUser(String email, String pwd) {
		System.out.println("In service of Authenticate user");
		return dao.authenticateUser(email, pwd);
	}
	public String signUp(User u) {
		System.out.println("In service:SignUp");
		return dao.signUp(u);
	}
}
