package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Book;
import com.app.service.IBookService;

@Controller
@RequestMapping("/book")
public class BookController {
	
	
	@Autowired
	private IBookService service;
	
public BookController() {

System.out.println("In construct of "+getClass().getName());
}

@GetMapping("/list")
public String showAllBookList(Model map,HttpSession hs)
{
	System.out.println("In show Book List Page.."+map);
	
	hs.setAttribute("Book_List", service.showAllBookList());
	return "/book/list";
}
@GetMapping("/listAdmin")
public String showAllBookListForAdmin(Model map,HttpSession hs)
{
	System.out.println("In show Book List Page.."+map);
	
	hs.setAttribute("Book_List", service.showAllBookList());
	return "/admin/bookList";
}


@GetMapping("/add")
public String addBookForm()
{
	System.out.println("IN add book");
	return "/book/add";
}

@PostMapping("/add")
public String processAddBook(HttpServletRequest req,HttpServletResponse res,HttpSession hs)
{
	System.out.println("In process add book");
	//int id=Integer.parseInt(req.getParameter("bookId"));
	String name=(req.getParameter("name"));
	String author=(req.getParameter("author"));
	String stream=(req.getParameter("stream"));
	String year=(req.getParameter("year"));
	double price=Double.parseDouble(req.getParameter("price"));
	Book b=new Book(1,name,author,stream,year,price);
	hs.setAttribute("status", service.addBook(b));
	System.out.println("After adding book");
	return "redirect:/book/list";
}


  @GetMapping("/buyBook") 
  public String buyBook(@RequestParam int bid,@RequestParam int uid,Model map,HttpSession hs) {
  map.addAttribute("brought book", service.buyBook(bid, uid));
  hs.setAttribute("orderList", service.showOrderList(bid, uid)); 
	  return "/customer/order"; 
	  }
 

}
