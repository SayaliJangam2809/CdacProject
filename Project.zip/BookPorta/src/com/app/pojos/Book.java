package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="book")
public class Book {
//id,name,author,stream,year,price,
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int b_id;
	
	//@ManyToOne
	//private Cart cartid;
	
	//@ManyToOne
	//private User userid;
	
	@Column(length = 30)
	private String name;
	
	@Column(length = 30)
	private String author;
	
	@Column(length = 30)
	private String stream;
	
	@Column(length = 30)
	private String year;
	
	private double price;

	public Book() {
		System.out.println("In def constr of Book..");
	}

	public Book(int b_id, String name, String author, String stream, String year, double price) {
		super();
		this.b_id = b_id;
		this.name = name;
		this.author = author;
		this.stream = stream;
		this.year = year;
		this.price = price;
	}

	
	/*
	 * public User getUserid() { return userid; }
	 */

	/*
	 * public void setUserid(User userid) { this.userid = userid; }
	 */

	public int getB_id() {
		return b_id;
	}

	public void setB_id(int b_id) {
		this.b_id = b_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	/*
	 * public Cart getCartid() { return cartid; }
	 */

	/*
	 * public void setCartid(Cart cartid) { this.cartid = cartid; }
	 */

	@Override
	public String toString() {
		return "Book [b_id=" + b_id + ", name=" + name + ", author=" + author + ", stream=" + stream + ", year=" + year
				+ ", price=" + price + "]";
	}
	
	
	
	
}
